//? n=_X_ AND _X_>0
function sum(n: number) {
  let i = 0;
  let j = 0;
  //? j = (i*(i+1))//2 AND n=_X_ AND _X_>0
  while (i != n+1) {
    i = i+1;
    j = j+i;
  }
}//? j = (_X_*(_X_+1))//2
