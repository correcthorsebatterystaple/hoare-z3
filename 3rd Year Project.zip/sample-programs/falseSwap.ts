//? a=_X_ AND b=_Y_
function falseSwap(a: number, b: number) {
  a = b;
  b = a;
} //? a=_Y_ AND b=_X_
