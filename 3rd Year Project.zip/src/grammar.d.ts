import { CompiledRules } from "nearley";

declare const grammar: CompiledRules;
export = grammar;
